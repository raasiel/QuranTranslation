quranApp.controller ('HomeController', function ($scope, navSvc, $routeParams,$http){

    $scope.QuranData = QuranData;

    // Navigate to
    $scope.slidePage = function (path,type) {
        navSvc.slidePage(path,type);
    };

    $scope.view = function (translation) {
        console.log ( "from home sending to " + translation.name);
        navSvc.slidePage("/sura/" + translation.name);
    };

    // Navigate back
    $scope.back = function () {
        navSvc.back();
    };

});

quranApp.controller ('SuraController', function ($scope, navSvc, $routeParams,$http){

    $scope.QuranData = QuranData;

    //alert("on sura controller");

    $scope.$on('$routeChangeSuccess', function (ev, current, previous) {
        if ($scope.translationName== null){
            $scope.translationName = current.params.translationName;
            console.log("found translation Name : " + $scope.translationName);
        }
    });

        // Navigate to
    $scope.slidePage = function (path,type) {
        navSvc.slidePage(path,type);
    };

    $scope.view = function (suraIndex,suraName) {
        //alert($scope.translationName);
        navSvc.slidePage("/sura/" + $scope.translationName + "/" + suraIndex + "/" +suraName);
    };

    // Navigate back
    $scope.back = function () {
        navSvc.back();
    };

});



quranApp.controller ('AyatController', function ($scope, navSvc, $routeParams,$http){

    $scope.QuranData = QuranData;

    //alert('on ayat controller');

    $scope.$on('$routeChangeSuccess', function (ev, current, previous) {
        //alert('on ayat controller change')
        $scope.translationName = current.params.translationName;
        $scope.suraIndex = current.params.suraIndex;
        $scope.suraName = current.params.suraName;

        var filename = QuranData.Translations[$scope.translationName].filename;

        alert(filename);
        $http({method: 'GET', url: '/translations/' + filename}).
            success(function(data, status, headers, config) {
                alert(data);
                start = QuranData.Sura[$scope.suraIndex][0];
                length = QuranData.Sura[$scope.suraIndex][1];
                var ayats = Array();
                var lines = data.split('\n');
                for (i = start;i<start+length;i++){
                 ayats.push(lines[i]);
                }

                $scope.ayats = ayats;
                //$scope.$apply();
            }).
            error(function(data, status, headers, config) {
                // called asynchronously if an error occurs
                // or server returns response with an error status.
                alert("fail" + status.toString());
            });

    });



    // Navigate to
    $scope.slidePage = function (path,type) {
        navSvc.slidePage(path,type);
    };

    $scope.view = function (translationName) {
        //alert(translationName);
    };

    // Navigate back
    $scope.back = function () {
        navSvc.back();
    };

});


















quranApp.controller ('ServerEditController', function ($scope, navSvc, tfsSvc, $routeParams,$location){

    $scope.$on('$routeChangeSuccess', function (ev, current, previous) {
        $scope.server = tfsSvc.getServerByName( $routeParams.id );
        if ($location.$$url =="/newserver"){
            $scope.server = new TFSServer();
            $scope.server.name ="(new)";
        }
    });

    // Navigate to
    $scope.slidePage = function (path,type) {
        navSvc.slidePage(path,type);
    };

    // Navigate back
    $scope.back = function () {
        navSvc.back();
    };

    // Navigate back
    $scope.save= function () {
        if ($location.$$url =="/newserver"){
            tfsSvc.addNewServer($scope.server);
        } else {
            tfsSvc.updateServer($scope.server);
        }
        $scope.back();
    };

});

quranApp.controller ('ProjectListController', function ($scope, navSvc, tfsSvc, $routeParams,$location, $http){

    $scope.$on('$routeChangeSuccess', function (ev, current, previous) {
        $scope.server = tfsSvc.getServerByName( $routeParams.id );
        alert(1);
        tfsSvc.getProjects($scope.server, function (response) {
            alert (response.body);
        }, function (response){
                alert ("fail");
            }
        )

    });

    // Navigate to
    $scope.slidePage = function (path,type) {
        navSvc.slidePage(path,type);
    };

    // Navigate back
    $scope.back = function () {
        navSvc.back();
    };
});

quranApp.controller ('WebCallController', function ($scope, navSvc, tfsSvc, $routeParams,$location, $http){


    $scope.$on('$routeChangeSuccess', function (ev, current, previous) {
    });

    $scope.run = function(){
        try{
            url = "/tfs/_api/_common/GetJumpList?__v=3&navigationContextPackage=%7B%22Action%22%3A%22index%22%2C%22Area%22%3A%22%22%2C%22Level%22%3A2%2C%22Controller%22%3A%22home%22%7D&showStoppedCollections=false";
            protocol = "https";
            host ="cmra.wkglobal.com"
            port =8088
            relativeUri = url;
            window.plugins.HttpClientNTLM.execute("https","cmra.wkglobal.com", 8088, relativeUri ,"GET","",{"Test":"this"},function(respose){
                    alert('Success: ' +  respose.headers);
                    $scope.callresult = respose;
                    $scope.callresult.json = JSON.parse(callresult.body);
                    $scope.$digest();

                }, function (response){
                    alert('Failure : ' + response);
                },
                "Shafqat.Ahmed","Today123","NA"
            );
        }
        catch (e){
            alert(e.message);
        }

    }

    // Navigate to
    $scope.slidePage = function (path,type) {
        navSvc.slidePage(path,type);
    };

    // Navigate back
    $scope.back = function () {
        navSvc.back();
    };
});
